import pygame
import random
import math
import os
import pygame, sys
import csv
from pathlib import Path

pygame.init()

#screen set
screen_width = 1200
screen_height = 600
screen = pygame.display.set_mode((screen_width,screen_height))


##ABOUT TIME
#set framrate
clock = pygame.time.Clock()
FPS = 60
current_time = 0

#set cooldown player skill
cooldown_normalATK = 0
cooldown_counterATK = 0

#set cooldown boss skill
cooldown_skill1 = 0
cooldown_skill2 = 0
cooldown_skill3 = 0
cooldown_skill4 = 0

#define colors
RED = (255, 0, 0)
YELLOW = (255, 255, 0)
WHITE = (255, 255, 255)
green = (92, 145, 101)
bright_green = (121, 175, 127)
salmon = (250, 128, 114)
salmon_light = (255, 160, 122)
red_light = (255, 100, 120)

'''
if os.path.exists('leaderboard.txt'):
    with open('leaderboard.txt', 'r') as file:
        timer = int(file.read())
else:
    timer = 0
'''
#define game variables
#intro_count = 3
#last_count_update = pygame.time.get_ticks()

#screen caption
pygame.display.set_caption("HELL_SLAYER")
icon = pygame.image.load('icon.jpg')
pygame.display.update()
pygame.display.set_icon(icon)

#define Player & BOSS Variable
Player_SIZE = 192
Player_SCALE = 2
Player_OFFSET = [72,56]
Player_DATA = [Player_SIZE, Player_SCALE, Player_OFFSET]

Boss_SIZE = 288
Boss_SCALE = 3
Boss_OFFSET = [112,107]
Boss_DATA = [Boss_SIZE, Boss_SCALE, Boss_OFFSET]

#load spritesheets
Player_sheet = pygame.image.load("player_sheet_nobg.png").convert_alpha()
BOSS_sheet = pygame.image.load("demon_slime_FREE_v1.0_288x160_spritesheet.png").convert_alpha()

#define animation_steps

PLAYER_ANIMATION_STEPS = [2, 3, 8, 13, 13, 7, 4, 4]  #idle jump running attacking heavy-attack death hit-knockback dash
BOSS_ANIMATION_STEPS = [6, 12, 15, 5, 22] #idle running attacking hit death

#define font
count_font = pygame.font.Font("GAME_font.ttf", 80)
count_font = pygame.font.Font("GAME_font.ttf", 30)
font_small = pygame.font.Font("GAME_font.ttf", 30)
font_smaller = pygame.font.Font("GAME_font.ttf", 20)
font_smallest = pygame.font.Font("GAME_font.ttf", 15)
'''
def update_high_scores():
    global timer
    filename = r"leaderboard.txt"  # file must exist
    with open(filename, "r") as file:
        line = file.readline()  # scores are one line
        leaderboard = [int(s) for s in line.split()]  # read scores as integers
    if timer in leaderboard:  # if current score already in high scores
        return # no update needed

    leaderboard.append(timer)  # add current score

    leaderboard.sort()  # sort scores  (low - high)

    with open(filename, "w") as file:  # updates score file
        for timer in leaderboard[::-1]:  # write scores in reverse (high - low)
            file.write(str(leaderboard) + " ")
'''

#function for drawing text
def draw_text(text, font, text_col, x, y):
    img = font.render(text, True, text_col)
    screen.blit(img, (x, y))

#function for drawing info panel

leaderBoard = []
if Path('highscore.csv').is_file() == False:
    tmp_list = ['xxx', 0]
    for x in range(5):
        leaderBoard.append(tmp_list)

    with open("highscore.csv", 'w', newline='') as csvfile:
        writer = csv.writer(csvfile, delimiter=',')
        for x in range(5):
            writer.writerow(leaderBoard[x])
else:
    with open("highscore.csv", 'r', newline='') as csvfile:
        reader = csv.reader(csvfile, delimiter=',')
        for x in reader:
            leaderBoard.append(x)

#background
def draw_bg():
    background = pygame.image.load("Background.png")
    background_new = pygame.transform.scale(background, (screen_width,screen_height))
    screen.blit(background_new, (0,0))

#function for drawing health bar
def draw_health_bar(health, x, y):
    ratio = health / 100
    pygame.draw.rect(screen, WHITE, (x - 2, y - 2, 204 , 34))
    pygame.draw.rect(screen, RED, (x, y, 200 , 30))
    pygame.draw.rect(screen, YELLOW, (x, y, 200 * ratio, 30))
    
def draw_health_bar_boss(health, x, y):
    ratio = health / 5000
    pygame.draw.rect(screen, WHITE, (x - 2, y - 2, 404 , 34))
    pygame.draw.rect(screen, RED, (x, y, 400 , 30))
    pygame.draw.rect(screen, YELLOW, (x, y, 400 * ratio, 30))

def event_ESC_pressed(get_pressed):
    if get_pressed[pygame.K_ESCAPE]:
        exit() #or pygame.quit()

#button class

class Player():
    def __init__(self, x, y, flip, data, sprite_sheet, animation_steps):
        self.size = data[0]
        self.image_scale = data[1]
        self.offset = data[2]
        self.flip = flip
        self.flip_playercontrol = flip
        self.animation_list = self.load_images(sprite_sheet, animation_steps)
        self.action = 0 #0: idle 1: jump 2: running 3: attacking 4:heavy-attack 5: death 6: hit 7: dash 
        self.frame_index = 0
        self.image = self.animation_list[self.action][self.frame_index] 
        self.update_time = pygame.time.get_ticks()
        self.update_time_normalattack = pygame.time.get_ticks()
        self.update_time_heavyattack = pygame.time.get_ticks()
        self.rect = pygame.Rect((x, y, 45, 70))
        self.vel_y = 0
        self.running = False
        self.jump = False
        self.dash = False
        self.attacking = False
        self.ult = 0
        self.normal_attacking = False
        self.heavy_attacking = False
        self.attack_type = 0
        self.dash_cooldown = 0
        self.attack_cooldown = 0
        self.immune_cooldown = 0
        self.hit = False
        self.health = 100
        self.alive = True
        self.revive_cooldown = 0
        #button upgrade status
        #self.strength = 1
        #self.agility = 1
        #self.charge_attack = 1

    def load_images(self, sprite_sheet, animation_steps):
        #extract images from spritesheet
        animation_list = []
        for y, animation in enumerate(animation_steps):
            temp_img_list = []
            for x in range(animation):
                temp_img = sprite_sheet.subsurface(x*self.size, y*self.size/2, self.size, self.size/2)
                temp_img_list.append(pygame.transform.scale(temp_img, (self.size * self.image_scale, self.size * self.image_scale/2)))
            animation_list.append(temp_img_list)
        #print(animation_list)
        return animation_list

    #move
    def move(self, screen_width, screen_height, surface, target):
        SPEED = 7
        GRAVITY = 2
        dx = 0
        dy = 0
        self.running = False
        self.attack_type = 0
        #get keypresses
        key = pygame.key.get_pressed()
        
        #movement
        if self.attacking == False and self.alive == True:
            if key[pygame.K_a]:
                dx = -(SPEED + (1/20 * agility))
                self.running = True 
                self.flip_playercontrol = True
            if key[pygame.K_d]:
                dx = (SPEED + (1/20 * agility))
                self.running = True
                self.flip_playercontrol = False
            
            #jump
            if key[pygame.K_w] and self.jump == False:
                self.vel_y = -35 
                self.jump = True
                self.dash = False

            #dash
            if key[pygame.K_LSHIFT] and self.dash == False:
                dx *= 2.5
                #self.dash = True

            #attack
            #if key[pygame.K_k] or key[pygame.K_p]:
                #determine which attack type was used
                    
            if key[pygame.K_k]:
                    #self.attack(surface, target)
                self.attack_type = 1
                self.attack(surface, target)
            if key[pygame.K_o ] and self.ult == 5:
                    #self.heavy_attack(surface, target)
                print('ready for charge')
                self.attack_type = 2
                self.attack(surface, target)
            #apply gravity
            self.vel_y += GRAVITY
            dy += self.vel_y

        #ensure player stays on screen
        if self.rect.left + dx < 0:
            dx = -self.rect.left
        if self.rect.right + dx > screen_width:
            dx = screen_width - self.rect.right
        if self.rect.bottom + dy > screen_height - 50:
            self.vel_y = 0
            self.jump = False
            self.dash = True
            dy = screen_height - 50 - self.rect.bottom

        #apply attack cooldown
        if self.attack_cooldown > 0:
            self.attack_cooldown -= 1

        if self.dash_cooldown > 0:
            self.dash_cooldown -= 1
        #update player pos
        self.rect.x += dx
        self.rect.y += dy
    

    #handle animation updates
    def update(self, surface, target):
        #check what action the player is performing
        if self.health <= 0 and self.revive_cooldown == 1:
            self.health  = 50
            self.alive = True
        if self.health <= 0:
            self.health = 0
            self.revive_cooldown = 100
            self.alive = False
            self.update_action(5) #death
        elif self.hit == True:
            self.update_action(6) #hit
        elif self.attacking == True:
            if self.attack_type == 1:
                self.update_action(3) # normal atk
            elif self.attack_type == 2:
                self.update_action(4) #heavy atk
                print('hello')
        elif self.jump == True:
            self.update_action(1) #jump
        elif self.running == True:
            self.update_action(2) #running
        else:
            self.update_action(0) #idle

        animation_cooldown = 50 - 2*(1/5 * agility)
        damage_attack = 50 + strength #self.strength
        self.image = self.animation_list[self.action][self.frame_index]
        #check if enough time has passed since last update
        if pygame.time.get_ticks() - self.update_time > animation_cooldown:
            self.frame_index += 1
            self.update_time = pygame.time.get_ticks()
            if self.action == 3:
                if self.frame_index == 7 or self.frame_index == 10: 
                    attacking_rect = pygame.Rect(self.rect.centerx - (2 * self.rect.width * self.flip_playercontrol), self.rect.y, 2 * self.rect.width - 20, self.rect.height)
                    if attacking_rect.colliderect(target.rect):
                        target.health -= damage_attack/ 2
                        self.health += 0.5
                        if self.health >= 100:
                            self.health = 100
                        target.hit = True
                    #pygame.draw.rect(surface, (0, 255, 0), attacking_rect)
            if self.action == 4:
                if self.frame_index == 8:
                    attacking_rect = pygame.Rect(self.rect.centerx - (2 * self.rect.width * self.flip_playercontrol), self.rect.y, 2 * self.rect.width+10 , self.rect.height)
                    if attacking_rect.colliderect(target.rect):
                        target.health -= damage_attack * 4 * (1 + charge)
                        #print('charge', charge)
                        target.hit = True
                    #pygame.draw.rect(surface, (0, 255, 0), attacking_rect)       
        #check if the animation has finished
        if self.frame_index >= len(self.animation_list[self.action]):
            #if the player is death end the animation
            if self.alive == False:
                self.frame_index = len(self.animation_list[self.action])-1
            else:
                self.frame_index = 0
                #check if an attack was executed
                if self.action == 3 or self.action == 4:
                    self.attacking = False
                    self.attack_cooldown = 50 - 3 * (1/5 * agility) ##อาจมาแก้ให้มันแสดงผลตรงกับหน้าจอ หมายถึงตัวเลขบอก stats ที่เขียนไว้ มันเริ่มที่ 1.0
                if self.action == 6:
                    self.hit = False
                    self.attacking = False

    def attack(self, surface, target):
        damage_attack = 50 + strength #self.strength
        if self.attack_cooldown == 0:
            
            self.attacking = True
            if self.attack_type == 1:
                #self.normal_attacking = True
                attacking_rect = pygame.Rect(self.rect.centerx - (2 * self.rect.width * self.flip_playercontrol), self.rect.y, 2 * self.rect.width - 20, self.rect.height)
                if attacking_rect.colliderect(target.rect):
                    target.health -= damage_attack + strength
                    #print(damage_attack)
                    self.ult += 1
                    if self.ult >= 5:
                        self.ult = 5
                    print(self.ult)
                    target.hit = True
                    #pygame.draw.rect(surface, (0, 255, 0), attacking_rect)
            elif self.attack_type == 2:
                '''attacking_rect = pygame.Rect(self.rect.centerx - (2 * self.rect.width * self.flip_playercontrol), self.rect.y, 2 * self.rect.width - 10, self.rect.height)
                if attacking_rect.colliderect(target.rect):
                    target.health -= 250
                    target.hit = True
                pygame.draw.rect(surface, (0, 255, 0), attacking_rect)
                '''
                self.ult = 0
        #pygame.draw.rect(surface, (0, 255, 0), attacking_rect)    

    def draw(self, surface):
        img = pygame.transform.flip(self.image, self.flip_playercontrol, False)
        #pygame.draw.rect(surface, (255, 0, 0), self.rect)
        if self.flip_playercontrol == False:
            surface.blit(img, (self.rect.x - (self.offset[0] * self.image_scale) +74, self.rect.y - (self.offset[1] * self.image_scale)-10))
        elif self.flip_playercontrol == True:
            surface.blit(img, (self.rect.x - (self.offset[0] * self.image_scale) -124, self.rect.y - (self.offset[1] * self.image_scale)-10))
        
    def update_action(self, new_action):
        #check if the new action is diff to previous one
        if new_action != self.action:
            self.action = new_action 
            #update animation setting
            self.frame_index = 0
            self.update_time = pygame.time.get_ticks()


class Boss():

    def __init__(self, x, y, flip, data, sprite_sheet, animation_steps):
        self.size = data[0]
        self.image_scale = data[1]
        self.offset = data[2]
        self.flip = flip
        self.flip_bosscontrol = False
        self.flip_attack = False
        self.animation_list = self.load_images(sprite_sheet, animation_steps)
        self.action = 0 #idle running attacking hit death 
        self.frame_index = 0
        self.image = self.animation_list[self.action][self.frame_index]
        self.update_time_boss = pygame.time.get_ticks()
        self.rect = pygame.Rect((x, y, 130, 250))
        self.vel_y = 0
        self.running = False
        self.attacking = False
        self.attack_type = 0
        self.lightning_cooldown = 2
        self.attack_cooldown = 0
        self.cooldown_decrease = 1
        self.immune_cooldown = 0
        self.hit = False
        self.health = 5000
        self.alive = True
        self.next_phase = False
        self.check_once = False
        self.second_skill = False
        self.third_skill = False
        self.lightning_state = False

        self.second = 1
        self.third = 1
        self.range_attack = 1

    def load_images(self, sprite_sheet, animation_steps):
        #extract images from spritesheet
        animation_list = []
        for y, animation in enumerate(animation_steps):
            temp_img_list = []
            for x in range(animation):
                temp_img = sprite_sheet.subsurface(x*self.size, y*self.size/288*160, self.size, self.size/288*160)
                temp_img_list.append(pygame.transform.scale(temp_img, (self.size * self.image_scale, self.size * self.image_scale/280*160)))
            animation_list.append(temp_img_list)
        #print(animation_list)
        return animation_list

    def move(self, screen_width, screen_height, surface, target):
        SPEED = 1 * self.second
        dx = 0
        dy = 0
        self.running = False
        self.attack_type = 0
        #get keypresses
        if self.attacking == False and target.alive == True:
            if target.rect.centerx > self.rect.centerx :
                self.flip_bosscontrol = True
                self.flip_attack = False
                dx += SPEED
                self.running = True
                if self.rect.centerx - target.rect.centerx > -300 * self.second *self.third:
                    self.boss_attack(surface, target)
            else :
                self.flip_bosscontrol = False
                self.flip_attack = True
                self.running = True
                dx -= SPEED
                if self.rect.centerx - target.rect.centerx < 300 * self.second *self.third:
                    self.boss_attack(surface, target)
                    
                #ensure player stays on screen
            if self.rect.left + dx < 0:
                dx = -self.rect.left
            if self.rect.right + dx > screen_width:
                dx = screen_width - self.rect.right
            if self.rect.bottom + dy > screen_height - 50:
                self.vel_y = 0
                dy = screen_height - 50 - self.rect.bottom
            
            
            
                #update player pos
            self.rect.x += dx
            self.rect.y += dy
        if self.attack_cooldown > 0:
            self.attack_cooldown -= 1

        if self.immune_cooldown > 0:
            self.immune_cooldown -= 1
        if self.lightning_cooldown > 0:
            self.lightning_cooldown -=1
            print(self.lightning_cooldown)
       
        
    def lightning(self, surface, target):
        #print('eiei')
        global lightning_pos_x
        laser_pos_x = []
        if self.lightning_cooldown == 50 or self.lightning_cooldown == 1:
            if self.lightning_cooldown == 50: 
                lightning_pos_x = []
                for x in range(2):
                    rand_x = []
                    rand_x = random.randint(0, screen_width)   
                    laser_pos_x.append(rand_x)
                lightning_pos_x = laser_pos_x.copy()
                
                    
                laser_rect_one = pygame.Rect(laser_pos_x[0], 0, 5, screen_height-40)
                laser_rect_two = pygame.Rect(laser_pos_x[1], 0, 5, screen_height-40) 
                
                pygame.draw.rect(surface, WHITE, laser_rect_one)
                pygame.draw.rect(surface, WHITE, laser_rect_two)

            if self.lightning_cooldown == 1:
                lightning_rect_one = pygame.Rect(lightning_pos_x[0], 0, 50, screen_height-40)
                lightning_rect_two = pygame.Rect(lightning_pos_x[1], 0, 40, screen_height-40)
                if lightning_rect_one.colliderect(target.rect):
                        target.health -= 25
                        target.hit = True
                pygame.draw.rect(surface, WHITE, lightning_rect_one)
                #screen.blit(thunder1, (lightning_pos_x[0],0))

                if lightning_rect_two.colliderect(target.rect):
                        target.health -= 25
                        target.hit = True
                pygame.draw.rect(surface, WHITE, lightning_rect_two)
                #screen.blit(thunder2, (lightning_pos_x[1],0))
                self.second_skill = False 

    def boss_attack(self, surface, target):
        if self.attack_cooldown <= 0:
            self.attack_cooldown = 400 - (50 * self.cooldown_decrease) 
            self.attacking = True
            if self.next_phase == True:
                skill_unlocked = random.randint(2,3)
                if skill_unlocked == 2:
                    self.second_skill = True 
                else:
                    self.third_skill = True
                
    
    def reset_animation(self):
        #self.frame_index = 0
        self.running = False
        self.attacking = False
        self.hit = False
        self.idle = True


    def update(self, surface, target):       #idle running attacking hit death
        #check what action the player is performing
        if self.health <= 2500 and self.health > 0 and self.check_once == False:
            self.cooldown_decrease = 1.25
            self.next_phase = True
            self.check_once = True
            self.health += 2000
            self.second = 1.25
        elif self.lightning_state == True:
            self.lightning(screen, target)  
        elif self.health <= 0:
            self.health = 0
            self.alive = False
            self.update_action_boss(4) #death
        elif self.attacking == True:
            self.hit = False
            self.update_action_boss(2) #attack
            if(self.check_once == True):
                self.cooldown_decrease += 0.0025
        elif self.hit == True and self.attack_cooldown >= 0 and self.attacking == False:
            self.update_action_boss(3) # hit
        elif self.running == True:
            self.update_action_boss(1) #running
        else:
            self.update_action_boss(0) #idle

        animation_cooldown = 100 
        
        self.image = self.animation_list[self.action][self.frame_index]
        #check if enough time has passed since last update
        if pygame.time.get_ticks() - self.update_time_boss > animation_cooldown:
            self.frame_index += 1
            self.update_time_boss = pygame.time.get_ticks()
            if self.action == 2:
                if self.frame_index == 9:
                    attacking_rect = pygame.Rect(self.rect.centerx - (2 * self.rect.width * self.flip_attack) - 50, 20+ self.rect.y, 2*self.rect.width + 50, self.rect.height)
                    
                    if attacking_rect.colliderect(target.rect):
                        self.cooldown_decrease += 0.01
                        target.health -= 25
                        target.hit = True
                    
                    #pygame.draw.rect(surface, (0, 255, 0), attacking_rect)
              
                    if self.second_skill == True:
                        self.lightning_state = True
                        self.lightning_cooldown = 51
                        
                    if self.third_skill == True:
                        all_pos_x = pygame.Rect(0, screen_height-135, screen_width, 400)
                        if all_pos_x.colliderect(target.rect):
                                target.health -= 25
                                target.hit = True
                        pygame.draw.rect(surface, WHITE, all_pos_x)
                        self.third_skill = False
            if self.lightning_cooldown == 0:
                #self.lightning_cooldown = 51
                self.lightning_state = False           
                
        #check if the animation has finished
        if self.frame_index >= len(self.animation_list[self.action]):
            if self.alive == False:
                self.frame_index = len(self.animation_list[self.action])-1
            else:
                self.frame_index = 0
                #check if an attack was executed  
                if self.action == 3:
                    self.hit = False
                    self.attacking = False
                    self.attack_cooldown -= 10
                if self.action == 2:
                    self.attacking = False 
                    #self.attack_cooldown = 800

    def draw(self, surface):
        img = pygame.transform.flip(self.image, self.flip_bosscontrol, False)
        #pygame.draw.rect(surface, (255, 0, 0), self.rect)
        if self.flip_bosscontrol == False:
            surface.blit(img, (self.rect.x - (self.offset[0] * self.image_scale) -45 , self.rect.y - (self.offset[1] * self.image_scale)+90))
        elif self.flip_bosscontrol == True:
            surface.blit(img, (self.rect.x - (self.offset[0] * self.image_scale) -45, self.rect.y - (self.offset[1] * self.image_scale)+90))
        
    def update_action_boss(self, new_action):
        #self.reset_animation()
        #check if the new action is diff to previous one
        if new_action != self.action:
            self.action = new_action 
            #update animation setting
            self.frame_index = 0
            self.update_time_boss = pygame.time.get_ticks()

#score count comments
score_value = 0
font = pygame.font.Font('GAME_font.ttf', 32)

textX = 10
textY = 10

def quit_game():
    pygame.quit()
    quit()

def game_intro():

    intro = True
    while intro:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
            
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_i:
                    main_loop()
                
                #(msg, x, y, w, h, ic, ac, action=None)


        draw_bg()
        button("START", 50, 320, 150, 60, green, bright_green, before_mainloop)
        button("QUIT", 50, 400, 150, 60, green, bright_green, quit_game)
        pygame.display.update()

def before_mainloop():

    bef= True
    while bef:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()

        draw_bg()
        button("GO", 500, 360, 150, 60, green, bright_green, main_loop)
        pygame.display.update()

def button(msg, x, y, w, h, ic, ac, action=None):
    mouse = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()

    if x+w > mouse[0] > x and y+h > mouse[1] > y:
        pygame.draw.rect(screen, ac, (x,y,w,h))

        if click[0] == 1 and action != None:
            action()

    else:
        pygame.draw.rect(screen, ic, (x,y,w,h))

    smallText = pygame.font.Font('GAME_font.ttf', 20)
    textSurf , textRect = text_object(msg, smallText)
    textRect.center = ((x + (w/2)), (y + (h/2)))
    screen.blit(textSurf, textRect)

# def game_over_text():
#     over = True
#     while over:
#         for event in pygame.event.get():
#             if event.type == pygame.QUIT:
#                 pygame.quit()
#                 quit()

#         over_text = over_font.render('GAME OVER', True, WHITE)
#         screen.blit(over_text, (150,200)) 

def text_object(text, font):
    textSurface = font.render(text, True, WHITE)
    return textSurface, textSurface.get_rect()

##PAUSE / UNPAUSE
def paused():
    pygame.mixer.music.pause()
    font = pygame.font.Font('GAME_font.ttf', 30)
    largeText = pygame.font.Font('GAME_font.ttf', 60)
    TextSurf, TextRect = text_object('Paused', largeText)
    TextRect.center = (600,300)
    screen.blit(TextSurf, TextRect)

    while pause:
        for event in  pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_c:
                    unpause()
                

        pygame.display.update()
        #clock.tick(15)

def unpause():
    global pause
    pygame.mixer.music.unpause()
    pause = False



#loop
def main_loop():
    global pause
    global delay 
    delay = 0
    global status_STR 
    status_STR = False
    global status_AGI 
    status_AGI = False
    global status_CHR
    status_CHR = False
    
    global damage_attack 
    global strength
    global agility
    global charge
    strength = 0
    agility = 0
    charge = 0
    global skill_point
    skill_point = 10
    i = 1

    smallText = pygame.font.Font('GAME_font.ttf', 20)
    TextSurf01, TextRect01 = text_object('TIME: ', smallText)
    TextRect01.center = (600,50)
    global time_start
    time_start = 0 #(current_time - time_start)/1000
    def draw_panel():
            draw_text(('TIME: ' + str((current_time - time_start)/1000)), font_small, WHITE, screen_width/2 - 300, 50)
    def draw_timer_end():
            draw_text(('TIME: ' + str((time_end - time_start)/1000)), font_small, WHITE, screen_width/2 - 300, 50)
    def draw_ATK():
            draw_text(('ATK: ' + str(50 + strength)), font_smaller, WHITE, 10, 100)
    def draw_AGI():
            draw_text(('AGI: ' + str(agility)), font_smaller, WHITE, 10, 150)
    def draw_charge():
            draw_text(('CHARGE: ' + str(1+charge)), font_smaller, WHITE, 10, 200)
    def draw_skill_point():
            draw_text(('skill_points: ' + str(skill_point)), font_smallest, WHITE, 10, 250)
    #timer = (current_time-time_start)/1000 
    #main game variable
    player_x = 0
    player_y = 410
    player_x_change = 0

    #enemy
    enemyImg = []
    enemyX = []
    enemyY = []
    enemyX_change = []
    enemyY_change = []
    num_of_enemies = 5

    #bullet
    bulletImg1 = pygame.image.load('bulletT.png')
    bulletImg = pygame.transform.scale(bulletImg1, (75,75))
    bulletX = 0
    bulletY = 400
    bulletX_change = 2
    bulletY_change = 0
    bullet_state = "ready"
   
    textX = 10
    textY = 10
    score_value = 0
    intro_count = 3
    last_count_update = pygame.time.get_ticks()
    TIME = [0]
    round_over = False


    Player_1 = Player(200, 400, False, Player_DATA,  Player_sheet, PLAYER_ANIMATION_STEPS)
    BOSS = Boss(1000, 300, False, Boss_DATA, BOSS_sheet, BOSS_ANIMATION_STEPS)

    open = True
    while open:
        
        #def draw_panel():
            #draw_text('TIME: ' + str(current_time/1000), font_small, WHITE, screen_width/2 - 300, 50)

        def strength_upgrade():
            global status_STR
            status_STR = True

        def agility_upgrade():
            global status_AGI
            status_AGI = True
        
        def charge_upgrade():
            global status_CHR
            status_CHR = True

        #global current_time
        current_time = pygame.time.get_ticks()
        global timer
        timer = (current_time - time_start)/1000
        #print(current_time)

        clock.tick(FPS)

        get_pressed = pygame.key.get_pressed() # ESC to exit game
        event_ESC_pressed(get_pressed)

        #loop background
        draw_bg()
        
        
        #show health bar
        draw_health_bar(Player_1.health, 20, 20)
        draw_health_bar_boss(BOSS.health, 780, 20)

        #update countdown
        if intro_count <= 0:
            #move fighter
            if i == 1:
                time_start = pygame.time.get_ticks()
                i+=1
            if BOSS.alive == False and i == 2:
                time_end = current_time 
                i+=1
            if i==3:
                draw_timer_end()
            #print(time_start)
            BOSS.move(screen_width, screen_height, screen, Player_1)
            Player_1.move(screen_width, screen_height, screen, BOSS)
            
            if BOSS.alive == True:
                draw_panel()
        else:
            #display count timer
            draw_text(str(intro_count), count_font, WHITE, screen_width /2, screen_height/3)
            #update count timer
            if (pygame.time.get_ticks()- last_count_update) >= 1000:
                intro_count -= 1
                last_count_update = pygame.time.get_ticks()
        
        #draw_text(f"Time : {current_time}", WHITE, screen_width/2, 20, "GAME_font.ttf")
        #screen.blit(TextSurf01, TextRect01)
        draw_ATK()
        draw_AGI()
        draw_charge()
        draw_skill_point()
        #update Player
        Player_1.update(screen, BOSS)
        BOSS.update(screen, Player_1)

        #draw Player and ENEMY
        Player_1.draw(screen)
        BOSS.draw(screen)

        #check for player defeat
        if round_over == False:
            if BOSS.alive == False:
                draw_text('VICTORY', count_font, WHITE, screen_width /2 -150, screen_height/3)
                #update_high_scores()
                '''
                if round_over == False and BOSS.alive == False:
                    with open('leaderboard.txt', 'w') as file:
                        file.write(str(timer))
                        '''
            if Player_1.alive == False:
                draw_text('GAME OVER', count_font, WHITE, screen_width /2 -150, screen_height/3)
        
        #button in main_loop
        button("BACK TO MENU", 10, screen_height - 25, 300, 25, salmon, salmon_light, game_intro)
        button("+", 10, 60, 50, 25, salmon, salmon_light, strength_upgrade)
        button("+", 65, 60, 50, 25, green, bright_green, agility_upgrade)
        button("+", 120, 60, 50, 25, RED, red_light, charge_upgrade)

        if skill_point > 0 and current_time - delay > 100:
            if status_STR == True:
                strength += 5
                skill_point -= 1
                status_STR = False

            if status_AGI == True:
                agility += 5
                skill_point -= 1
                status_AGI = False
                
            if status_CHR == True:
                charge += 0.5
                skill_point -= 1
                status_CHR = False
            delay = pygame.time.get_ticks()
            #print(skill_point)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                quit()
                running = False
                score = False
            
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_p:
                    pause = True
                    paused()


        '''
        collision = isCollision(enemyX[i], enemyY[i], bulletX, bulletY)
        if collision:
            bulletY = 370
            bullet_state = "ready"
            score_value += 1
            enemyX[i] = random.randint(0,700)
            enemyY[i] = random.randint(50,150)
        
        enemy(enemyX[i], enemyY[i], i)
        '''

        pygame.display.update()

game_intro()
#before_mainloop()
main_loop()
quit()